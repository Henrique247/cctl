import { initializeApp } from "firebase/app"
import { getDatabase } from "firebase/database"
import { getAuth } from "firebase/auth"
import { getStorage } from "firebase/storage"

const firebaseConfig = {
  apiKey: "AIzaSyB0bvEj_oct1cMcCWU9ZwqrGy1cyAtHrSU",
  authDomain: "cctl-2025.firebaseapp.com",
  databaseURL: "https://cctl-2025-default-rtdb.firebaseio.com",
  projectId: "cctl-2025",
  storageBucket: "cctl-2025.firebasestorage.app",
  messagingSenderId: "228758746383",
  appId: "1:228758746383:web:2df20530ca267371a77a7a",
}

// Initialize Firebase
const app = initializeApp(firebaseConfig)

// Initialize services
export const database = getDatabase(app)
export const auth = getAuth(app)
export const storage = getStorage(app)

export default app
