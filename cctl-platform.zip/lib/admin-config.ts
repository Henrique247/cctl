export const ADMIN_KEY = "YnM7BY3i1IhXo4MT1zxDgO4Bu2x1"

export function validateAdminKey(inputKey: string): boolean {
  return inputKey === ADMIN_KEY
}
