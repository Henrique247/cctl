"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { database } from "@/lib/firebase-config"
import { ref as dbRef, push, onValue } from "firebase/database"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Loader2, AlertCircle, ArrowLeft } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import Image from "next/image"
import Link from "next/link"

export default function CandidaturaPage() {
  const router = useRouter()
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState(false)
  const [cargos, setCargos] = useState<string[]>([])

  const [formData, setFormData] = useState({
    nomeCompleto: "",
    email: "",
    telefone: "",
    cargo: "",
    motivacao: "",
    idade: "",
    habilidades: "",
  })

  useEffect(() => {
    console.log("[v0] Loading available job positions...")
    const cargosRef = dbRef(database, "cargos")

    const unsubscribe = onValue(
      cargosRef,
      (snapshot) => {
        if (snapshot.exists()) {
          const data = snapshot.val()
          const cargosList = Object.keys(data)
            .map((key) => data[key])
            .filter((cargo) => cargo.status === "ativo")
            .map((cargo) => cargo.nome)
          setCargos(cargosList)
          console.log("[v0] Loaded cargos:", cargosList)
        } else {
          console.log("[v0] No cargos found in database")
        }
      },
      (error) => {
        console.error("[v0] Error loading cargos:", error)
      },
    )

    return () => unsubscribe()
  }, [])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setSubmitting(true)
    setError(null)

    console.log("[v0] Starting candidatura submission...")

    // Validate required fields
    if (!formData.nomeCompleto || !formData.email || !formData.telefone || !formData.cargo || !formData.motivacao) {
      setError("Por favor, preencha todos os campos obrigatórios")
      setSubmitting(false)
      console.log("[v0] Validation failed: missing required fields")
      return
    }

    if (formData.motivacao.length < 20) {
      setError("A motivação deve ter pelo menos 20 caracteres")
      setSubmitting(false)
      console.log("[v0] Validation failed: motivacao too short")
      return
    }

    try {
      console.log("[v0] Preparing data for submission...")

      // Save to database
      const candidaturasRef = dbRef(database, "candidaturas")
      const candidaturaData = {
        nomeCompleto: formData.nomeCompleto,
        email: formData.email,
        telefone: formData.telefone,
        cargo: formData.cargo,
        motivacao: formData.motivacao,
        idade: formData.idade || null,
        habilidades: formData.habilidades || null,
        status: "em análise",
        dataSubmissao: new Date().toISOString(),
      }

      console.log("[v0] Submitting to Firebase:", candidaturaData)
      await push(candidaturasRef, candidaturaData)
      console.log("[v0] Candidatura submitted successfully!")

      setSuccess(true)
      setFormData({
        nomeCompleto: "",
        email: "",
        telefone: "",
        cargo: "",
        motivacao: "",
        idade: "",
        habilidades: "",
      })
    } catch (error: any) {
      console.error("[v0] Error submitting candidatura:", error)
      console.error("[v0] Error code:", error.code)
      console.error("[v0] Error message:", error.message)

      if (error.code === "PERMISSION_DENIED" || error.message?.includes("permission")) {
        setError(
          "Erro de permissão no Firebase. Por favor, configure as regras de segurança para permitir escrita em 'candidaturas'.",
        )
      } else {
        setError(`Erro ao enviar candidatura: ${error.message || "Por favor, tente novamente."}`)
      }
    } finally {
      setSubmitting(false)
    }
  }

  if (success) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <Card className="max-w-md w-full">
          <CardHeader>
            <CardTitle className="text-2xl text-center text-green-600">Candidatura Enviada!</CardTitle>
          </CardHeader>
          <CardContent className="text-center space-y-4">
            <p className="text-muted-foreground">
              Sua candidatura foi enviada com sucesso. Entraremos em contato em breve.
            </p>
            <div className="flex flex-col gap-2">
              <Button onClick={() => setSuccess(false)}>Enviar Outra Candidatura</Button>
              <Button variant="outline" asChild>
                <Link href="/">Voltar para Página Inicial</Link>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-background sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link
            href="/"
            className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            <span className="text-sm">Voltar</span>
          </Link>
          <div className="flex items-center gap-3">
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/AuealqKvSx2PDBiPOATGAg-removebg-preview-WtroRwh6uTklZcQ0LotaTdHXdU5U6q.png"
              alt="CCTL Logo"
              width={40}
              height={40}
              className="object-contain"
            />
            <div>
              <h1 className="text-lg font-bold">CCTL</h1>
              <p className="text-xs text-muted-foreground hidden sm:block">Candidatura</p>
            </div>
          </div>
        </div>
      </header>

      {/* Form Section */}
      <section className="py-12 md:py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto">
            <div className="text-center mb-8">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Candidate-se à CCTL</h2>
              <p className="text-muted-foreground">
                Preencha o formulário abaixo para se candidatar a uma vaga na nossa equipe
              </p>
            </div>

            {error && (
              <Alert variant="destructive" className="mb-6">
                <AlertCircle className="h-4 w-4" />
                <AlertTitle>Erro</AlertTitle>
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            <Card>
              <CardHeader>
                <CardTitle>Formulário de Candidatura</CardTitle>
                <CardDescription>Campos marcados com * são obrigatórios</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  {/* Required Fields */}
                  <div className="space-y-4">
                    <h3 className="font-semibold text-lg">Informações Pessoais</h3>

                    <div>
                      <Label htmlFor="nomeCompleto">Nome Completo *</Label>
                      <Input
                        id="nomeCompleto"
                        required
                        value={formData.nomeCompleto}
                        onChange={(e) => setFormData({ ...formData, nomeCompleto: e.target.value })}
                        placeholder="Seu nome completo"
                      />
                    </div>

                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="email">Email *</Label>
                        <Input
                          id="email"
                          type="email"
                          required
                          value={formData.email}
                          onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                          placeholder="seu@email.com"
                        />
                      </div>

                      <div>
                        <Label htmlFor="telefone">Telefone *</Label>
                        <Input
                          id="telefone"
                          type="tel"
                          required
                          value={formData.telefone}
                          onChange={(e) => setFormData({ ...formData, telefone: e.target.value })}
                          placeholder="(00) 00000-0000"
                        />
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="cargo">Cargo/Vaga Desejada *</Label>
                      <select
                        id="cargo"
                        required
                        value={formData.cargo}
                        onChange={(e) => setFormData({ ...formData, cargo: e.target.value })}
                        className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                      >
                        <option value="">Selecione uma vaga</option>
                        {cargos.map((cargo, index) => (
                          <option key={index} value={cargo}>
                            {cargo}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <Label htmlFor="motivacao">Motivação / Experiência / Competências *</Label>
                      <Textarea
                        id="motivacao"
                        required
                        minLength={20}
                        value={formData.motivacao}
                        onChange={(e) => setFormData({ ...formData, motivacao: e.target.value })}
                        rows={6}
                        placeholder="Conte-nos sobre sua motivação, experiência e competências relevantes para esta vaga (mínimo 20 caracteres)"
                      />
                      <p className="text-xs text-muted-foreground mt-1">
                        {formData.motivacao.length} caracteres (mínimo 20)
                      </p>
                    </div>
                  </div>

                  {/* Optional Fields */}
                  <div className="space-y-4 pt-4 border-t">
                    <h3 className="font-semibold text-lg">Informações Adicionais (Opcional)</h3>

                    <div>
                      <Label htmlFor="idade">Idade</Label>
                      <Input
                        id="idade"
                        type="number"
                        min="16"
                        max="100"
                        value={formData.idade}
                        onChange={(e) => setFormData({ ...formData, idade: e.target.value })}
                        placeholder="Sua idade"
                      />
                    </div>

                    <div>
                      <Label htmlFor="habilidades">Habilidades</Label>
                      <Textarea
                        id="habilidades"
                        value={formData.habilidades}
                        onChange={(e) => setFormData({ ...formData, habilidades: e.target.value })}
                        rows={3}
                        placeholder="Liste suas principais habilidades técnicas e comportamentais"
                      />
                    </div>
                  </div>

                  <Button type="submit" className="w-full" size="lg" disabled={submitting}>
                    {submitting ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Enviando Candidatura...
                      </>
                    ) : (
                      "Enviar Candidatura"
                    )}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </div>
  )
}
