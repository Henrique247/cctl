"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { auth, database } from "@/lib/firebase-config"
import { onAuthStateChanged, signOut } from "firebase/auth"
import { ref, onValue } from "firebase/database"
import { validateAdminKey } from "@/lib/admin-config"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Loader2, LogOut, BookOpen, FileText, Users, Settings, Menu, Briefcase, UserCheck } from "lucide-react"
import CoursesManagement from "@/components/admin/courses-management"
import PublicationsManagement from "@/components/admin/publications-management"
import CandidatesManagement from "@/components/admin/candidates-management"
import SiteConfigManagement from "@/components/admin/site-config-management"
import CargosManagement from "@/components/admin/cargos-management"
import CandidaturasManagement from "@/components/admin/candidaturas-management"
import Image from "next/image"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"

export default function AdminDashboard() {
  const router = useRouter()
  const [loading, setLoading] = useState(true)
  const [authenticated, setAuthenticated] = useState(false)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const [activeTab, setActiveTab] = useState("courses")
  const [stats, setStats] = useState({
    courses: 0,
    publications: 0,
    candidates: 0,
    cargos: 0,
    candidaturas: 0,
  })

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      if (user) {
        const adminKey = sessionStorage.getItem("adminKey")
        if (adminKey && validateAdminKey(adminKey)) {
          setAuthenticated(true)
          loadStats()
        } else {
          router.push("/admin/login")
        }
      } else {
        router.push("/admin/login")
      }
      setLoading(false)
    })

    return () => unsubscribe()
  }, [router])

  const loadStats = () => {
    const coursesRef = ref(database, "cursos")
    onValue(coursesRef, (snapshot) => {
      if (snapshot.exists()) {
        setStats((prev) => ({ ...prev, courses: Object.keys(snapshot.val()).length }))
      }
    })

    const publicationsRef = ref(database, "publicacoes")
    onValue(publicationsRef, (snapshot) => {
      if (snapshot.exists()) {
        setStats((prev) => ({ ...prev, publications: Object.keys(snapshot.val()).length }))
      }
    })

    const candidatesRef = ref(database, "candidatos")
    onValue(candidatesRef, (snapshot) => {
      if (snapshot.exists()) {
        setStats((prev) => ({ ...prev, candidates: Object.keys(snapshot.val()).length }))
      }
    })

    const cargosRef = ref(database, "cargos")
    onValue(cargosRef, (snapshot) => {
      if (snapshot.exists()) {
        setStats((prev) => ({ ...prev, cargos: Object.keys(snapshot.val()).length }))
      }
    })

    const candidaturasRef = ref(database, "candidaturas")
    onValue(candidaturasRef, (snapshot) => {
      if (snapshot.exists()) {
        setStats((prev) => ({ ...prev, candidaturas: Object.keys(snapshot.val()).length }))
      }
    })
  }

  const handleLogout = async () => {
    try {
      await signOut(auth)
      sessionStorage.removeItem("adminKey")
      router.push("/admin/login")
    } catch (error) {
      console.error("Logout error:", error)
    }
  }

  const handleTabChange = (value: string) => {
    setActiveTab(value)
    setMobileMenuOpen(false)
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin" />
      </div>
    )
  }

  if (!authenticated) {
    return null
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-background sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/AuealqKvSx2PDBiPOATGAg-removebg-preview-WtroRwh6uTklZcQ0LotaTdHXdU5U6q.png"
              alt="CCTL Logo"
              width={40}
              height={40}
              className="object-contain"
            />
            <div>
              <h1 className="text-base md:text-lg font-bold">Painel Administrativo CCTL</h1>
              <p className="text-xs text-muted-foreground hidden sm:block">Gerenciamento de Conteúdo</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
              <SheetTrigger asChild className="lg:hidden">
                <Button variant="outline" size="icon">
                  <Menu className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="w-[280px]">
                <div className="flex flex-col gap-4 mt-8">
                  <Button
                    variant={activeTab === "courses" ? "default" : "ghost"}
                    className="justify-start"
                    onClick={() => handleTabChange("courses")}
                  >
                    <BookOpen className="mr-2 h-4 w-4" />
                    Cursos
                  </Button>
                  <Button
                    variant={activeTab === "publications" ? "default" : "ghost"}
                    className="justify-start"
                    onClick={() => handleTabChange("publications")}
                  >
                    <FileText className="mr-2 h-4 w-4" />
                    Publicações
                  </Button>
                  <Button
                    variant={activeTab === "candidates" ? "default" : "ghost"}
                    className="justify-start"
                    onClick={() => handleTabChange("candidates")}
                  >
                    <Users className="mr-2 h-4 w-4" />
                    Inscrições (Cursos)
                  </Button>
                  <Button
                    variant={activeTab === "cargos" ? "default" : "ghost"}
                    className="justify-start"
                    onClick={() => handleTabChange("cargos")}
                  >
                    <Briefcase className="mr-2 h-4 w-4" />
                    Cargos/Vagas
                  </Button>
                  <Button
                    variant={activeTab === "candidaturas" ? "default" : "ghost"}
                    className="justify-start"
                    onClick={() => handleTabChange("candidaturas")}
                  >
                    <UserCheck className="mr-2 h-4 w-4" />
                    Candidaturas (Cargos)
                  </Button>
                  <Button
                    variant={activeTab === "config" ? "default" : "ghost"}
                    className="justify-start"
                    onClick={() => handleTabChange("config")}
                  >
                    <Settings className="mr-2 h-4 w-4" />
                    Configurações
                  </Button>
                </div>
              </SheetContent>
            </Sheet>
            <Button variant="outline" onClick={handleLogout} size="sm">
              <LogOut className="mr-0 md:mr-2 h-4 w-4" />
              <span className="hidden md:inline">Sair</span>
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-4 md:py-8">
        <div className="grid grid-cols-2 md:grid-cols-5 gap-2 md:gap-4 mb-4 md:mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 p-3 md:p-6">
              <CardTitle className="text-xs md:text-sm font-medium">Cursos</CardTitle>
              <BookOpen className="h-3 w-3 md:h-4 md:w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent className="p-3 pt-0 md:p-6 md:pt-0">
              <div className="text-xl md:text-2xl font-bold">{stats.courses}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 p-3 md:p-6">
              <CardTitle className="text-xs md:text-sm font-medium">Publicações</CardTitle>
              <FileText className="h-3 w-3 md:h-4 md:w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent className="p-3 pt-0 md:p-6 md:pt-0">
              <div className="text-xl md:text-2xl font-bold">{stats.publications}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 p-3 md:p-6">
              <CardTitle className="text-xs md:text-sm font-medium">Inscrições</CardTitle>
              <Users className="h-3 w-3 md:h-4 md:w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent className="p-3 pt-0 md:p-6 md:pt-0">
              <div className="text-xl md:text-2xl font-bold">{stats.candidates}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 p-3 md:p-6">
              <CardTitle className="text-xs md:text-sm font-medium">Cargos</CardTitle>
              <Briefcase className="h-3 w-3 md:h-4 md:w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent className="p-3 pt-0 md:p-6 md:pt-0">
              <div className="text-xl md:text-2xl font-bold">{stats.cargos}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 p-3 md:p-6">
              <CardTitle className="text-xs md:text-sm font-medium">Candidaturas</CardTitle>
              <UserCheck className="h-3 w-3 md:h-4 md:w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent className="p-3 pt-0 md:p-6 md:pt-0">
              <div className="text-xl md:text-2xl font-bold">{stats.candidaturas}</div>
            </CardContent>
          </Card>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
          <TabsList className="hidden lg:grid w-full grid-cols-6">
            <TabsTrigger value="courses">
              <BookOpen className="mr-2 h-4 w-4" />
              Cursos
            </TabsTrigger>
            <TabsTrigger value="publications">
              <FileText className="mr-2 h-4 w-4" />
              Publicações
            </TabsTrigger>
            <TabsTrigger value="candidates">
              <Users className="mr-2 h-4 w-4" />
              Inscrições (Cursos)
            </TabsTrigger>
            <TabsTrigger value="cargos">
              <Briefcase className="mr-2 h-4 w-4" />
              Cargos/Vagas
            </TabsTrigger>
            <TabsTrigger value="candidaturas">
              <UserCheck className="mr-2 h-4 w-4" />
              Candidaturas (Cargos)
            </TabsTrigger>
            <TabsTrigger value="config">
              <Settings className="mr-2 h-4 w-4" />
              Configurações
            </TabsTrigger>
          </TabsList>

          <TabsContent value="courses">
            <CoursesManagement />
          </TabsContent>

          <TabsContent value="publications">
            <PublicationsManagement />
          </TabsContent>

          <TabsContent value="candidates">
            <CandidatesManagement />
          </TabsContent>

          <TabsContent value="cargos">
            <CargosManagement />
          </TabsContent>

          <TabsContent value="candidaturas">
            <CandidaturasManagement />
          </TabsContent>

          <TabsContent value="config">
            <SiteConfigManagement />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
