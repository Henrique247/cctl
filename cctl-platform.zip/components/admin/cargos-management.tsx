"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { database } from "@/lib/firebase-config"
import { ref, onValue, push, update, remove } from "firebase/database"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Loader2, Plus, Pencil, Trash2 } from "lucide-react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface Cargo {
  id: string
  nome: string
  descricao: string
  requisitos: string
  status: "ativo" | "inativo"
}

export default function CargosManagement() {
  const [cargos, setCargos] = useState<Cargo[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [editingCargo, setEditingCargo] = useState<Cargo | null>(null)
  const [formData, setFormData] = useState({
    nome: "",
    descricao: "",
    requisitos: "",
    status: "ativo" as "ativo" | "inativo",
  })

  useEffect(() => {
    const cargosRef = ref(database, "cargos")
    const unsubscribe = onValue(cargosRef, (snapshot) => {
      if (snapshot.exists()) {
        const data = snapshot.val()
        const cargosList = Object.keys(data).map((key) => ({
          id: key,
          ...data[key],
        }))
        setCargos(cargosList)
      } else {
        setCargos([])
      }
      setLoading(false)
    })

    return () => unsubscribe()
  }, [])

  const handleOpenDialog = (cargo?: Cargo) => {
    if (cargo) {
      setEditingCargo(cargo)
      setFormData({
        nome: cargo.nome,
        descricao: cargo.descricao,
        requisitos: cargo.requisitos,
        status: cargo.status,
      })
    } else {
      setEditingCargo(null)
      setFormData({
        nome: "",
        descricao: "",
        requisitos: "",
        status: "ativo",
      })
    }
    setDialogOpen(true)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    try {
      if (editingCargo) {
        const cargoRef = ref(database, `cargos/${editingCargo.id}`)
        await update(cargoRef, formData)
      } else {
        const cargosRef = ref(database, "cargos")
        await push(cargosRef, formData)
      }
      setDialogOpen(false)
    } catch (error) {
      console.error("Erro ao salvar cargo:", error)
      alert("Erro ao salvar cargo")
    }
  }

  const handleDelete = async (id: string) => {
    if (confirm("Tem certeza que deseja excluir este cargo?")) {
      try {
        const cargoRef = ref(database, `cargos/${id}`)
        await remove(cargoRef)
      } catch (error) {
        console.error("Erro ao excluir cargo:", error)
        alert("Erro ao excluir cargo")
      }
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <Loader2 className="w-6 h-6 animate-spin" />
      </div>
    )
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>Gerenciar Cargos/Vagas</CardTitle>
            <CardDescription>Adicione e gerencie as vagas disponíveis na CCTL</CardDescription>
          </div>
          <Button onClick={() => handleOpenDialog()}>
            <Plus className="mr-2 h-4 w-4" />
            Novo Cargo
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {cargos.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            Nenhum cargo cadastrado. Clique em "Novo Cargo" para adicionar.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Nome</TableHead>
                  <TableHead className="hidden md:table-cell">Descrição</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {cargos.map((cargo) => (
                  <TableRow key={cargo.id}>
                    <TableCell className="font-medium">{cargo.nome}</TableCell>
                    <TableCell className="hidden md:table-cell max-w-md truncate">{cargo.descricao}</TableCell>
                    <TableCell>
                      <span
                        className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                          cargo.status === "ativo" ? "bg-green-100 text-green-800" : "bg-gray-100 text-gray-800"
                        }`}
                      >
                        {cargo.status}
                      </span>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button variant="outline" size="sm" onClick={() => handleOpenDialog(cargo)}>
                          <Pencil className="h-4 w-4" />
                        </Button>
                        <Button variant="outline" size="sm" onClick={() => handleDelete(cargo.id)}>
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingCargo ? "Editar Cargo" : "Novo Cargo"}</DialogTitle>
            <DialogDescription>Preencha as informações do cargo/vaga</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label htmlFor="nome">Nome do Cargo *</Label>
              <Input
                id="nome"
                required
                value={formData.nome}
                onChange={(e) => setFormData({ ...formData, nome: e.target.value })}
                placeholder="Ex: Desenvolvedor Full Stack"
              />
            </div>

            <div>
              <Label htmlFor="descricao">Descrição *</Label>
              <Textarea
                id="descricao"
                required
                value={formData.descricao}
                onChange={(e) => setFormData({ ...formData, descricao: e.target.value })}
                rows={4}
                placeholder="Descreva as responsabilidades e atividades do cargo"
              />
            </div>

            <div>
              <Label htmlFor="requisitos">Requisitos *</Label>
              <Textarea
                id="requisitos"
                required
                value={formData.requisitos}
                onChange={(e) => setFormData({ ...formData, requisitos: e.target.value })}
                rows={4}
                placeholder="Liste os requisitos necessários para o cargo"
              />
            </div>

            <div>
              <Label htmlFor="status">Status</Label>
              <Select
                value={formData.status}
                onValueChange={(value: "ativo" | "inativo") => setFormData({ ...formData, status: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ativo">Ativo</SelectItem>
                  <SelectItem value="inativo">Inativo</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                Cancelar
              </Button>
              <Button type="submit">{editingCargo ? "Salvar Alterações" : "Criar Cargo"}</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </Card>
  )
}
