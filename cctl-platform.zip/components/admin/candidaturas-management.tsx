"use client"

import { useEffect, useState } from "react"
import { database } from "@/lib/firebase-config"
import { ref, onValue, update, remove } from "firebase/database"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Loader2, Mail, Download, Trash2 } from "lucide-react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface Candidatura {
  id: string
  nomeCompleto: string
  email: string
  telefone: string
  cargo: string
  motivacao: string
  idade?: string
  habilidades?: string
  status: string
  dataSubmissao: string
}

export default function CandidaturasManagement() {
  const [candidaturas, setCandidaturas] = useState<Candidatura[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const candidaturasRef = ref(database, "candidaturas")
    const unsubscribe = onValue(candidaturasRef, (snapshot) => {
      if (snapshot.exists()) {
        const data = snapshot.val()
        const candidaturasList = Object.keys(data)
          .map((key) => ({
            id: key,
            ...data[key],
          }))
          .sort((a, b) => new Date(b.dataSubmissao).getTime() - new Date(a.dataSubmissao).getTime())
        setCandidaturas(candidaturasList)
      } else {
        setCandidaturas([])
      }
      setLoading(false)
    })

    return () => unsubscribe()
  }, [])

  const handleStatusChange = async (id: string, newStatus: string) => {
    try {
      const candidaturaRef = ref(database, `candidaturas/${id}`)
      await update(candidaturaRef, { status: newStatus })
    } catch (error) {
      console.error("Erro ao atualizar status:", error)
      alert("Erro ao atualizar status")
    }
  }

  const handleSendEmail = (email: string, nome: string) => {
    window.location.href = `mailto:${email}?subject=Candidatura CCTL - ${nome}`
  }

  const handleDelete = async (id: string) => {
    if (confirm("Tem certeza que deseja excluir esta candidatura?")) {
      try {
        const candidaturaRef = ref(database, `candidaturas/${id}`)
        await remove(candidaturaRef)
      } catch (error) {
        console.error("Erro ao excluir candidatura:", error)
        alert("Erro ao excluir candidatura")
      }
    }
  }

  const handleExportCSV = () => {
    const headers = ["Nome", "Email", "Telefone", "Cargo", "Status", "Data de Submissão", "Idade"]
    const rows = candidaturas.map((c) => [
      c.nomeCompleto,
      c.email,
      c.telefone,
      c.cargo,
      c.status,
      new Date(c.dataSubmissao).toLocaleDateString("pt-BR"),
      c.idade || "N/A",
    ])

    const csvContent = [headers, ...rows].map((row) => row.join(",")).join("\n")
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" })
    const link = document.createElement("a")
    link.href = URL.createObjectURL(blob)
    link.download = `candidaturas_${new Date().toISOString().split("T")[0]}.csv`
    link.click()
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <Loader2 className="w-6 h-6 animate-spin" />
      </div>
    )
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <CardTitle>Candidaturas (Cargos da CCTL)</CardTitle>
            <CardDescription>Gerencie as candidaturas para vagas da CCTL ({candidaturas.length} total)</CardDescription>
          </div>
          <Button onClick={handleExportCSV} variant="outline">
            <Download className="mr-2 h-4 w-4" />
            Exportar CSV
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {candidaturas.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">Nenhuma candidatura recebida ainda.</div>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Nome</TableHead>
                  <TableHead className="hidden md:table-cell">Email</TableHead>
                  <TableHead className="hidden lg:table-cell">Telefone</TableHead>
                  <TableHead>Cargo</TableHead>
                  <TableHead className="hidden xl:table-cell">Data</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {candidaturas.map((candidatura) => (
                  <TableRow key={candidatura.id}>
                    <TableCell className="font-medium">{candidatura.nomeCompleto}</TableCell>
                    <TableCell className="hidden md:table-cell">{candidatura.email}</TableCell>
                    <TableCell className="hidden lg:table-cell">{candidatura.telefone}</TableCell>
                    <TableCell>{candidatura.cargo}</TableCell>
                    <TableCell className="hidden xl:table-cell">
                      {new Date(candidatura.dataSubmissao).toLocaleDateString("pt-BR")}
                    </TableCell>
                    <TableCell>
                      <Select
                        value={candidatura.status}
                        onValueChange={(value) => handleStatusChange(candidatura.id, value)}
                      >
                        <SelectTrigger className="w-[140px]">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="em análise">Em Análise</SelectItem>
                          <SelectItem value="aceito">Aceito</SelectItem>
                          <SelectItem value="recusado">Recusado</SelectItem>
                          <SelectItem value="entrevista">Entrevista</SelectItem>
                        </SelectContent>
                      </Select>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleSendEmail(candidatura.email, candidatura.nomeCompleto)}
                          title="Enviar Email"
                        >
                          <Mail className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleDelete(candidatura.id)}
                          title="Excluir"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
