"use client"

import { useEffect, useState } from "react"
import { database } from "@/lib/firebase-config"
import { ref, onValue, update, remove } from "firebase/database"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Eye, Trash2, Loader2, Mail, Download } from "lucide-react"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface Candidate {
  id: string
  nome: string
  email: string
  telefone: string
  cargo: string
  motivo?: string
  status?: "pendente" | "aceito" | "recusado"
  submittedAt?: string
}

export default function CandidatesManagement() {
  const [candidates, setCandidates] = useState<Candidate[]>([])
  const [loading, setLoading] = useState(true)
  const [viewDialogOpen, setViewDialogOpen] = useState(false)
  const [selectedCandidate, setSelectedCandidate] = useState<Candidate | null>(null)
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false)
  const [candidateToDelete, setCandidateToDelete] = useState<string | null>(null)

  useEffect(() => {
    const candidatesRef = ref(database, "candidatos")
    const unsubscribe = onValue(candidatesRef, (snapshot) => {
      if (snapshot.exists()) {
        const data = snapshot.val()
        const candidatesList = Object.keys(data)
          .map((key) => ({
            id: key,
            status: "pendente" as const,
            submittedAt: new Date().toISOString(),
            ...data[key],
          }))
          .sort((a, b) => {
            const dateA = a.submittedAt ? new Date(a.submittedAt).getTime() : 0
            const dateB = b.submittedAt ? new Date(b.submittedAt).getTime() : 0
            return dateB - dateA
          })
        setCandidates(candidatesList)
      } else {
        setCandidates([])
      }
      setLoading(false)
    })

    return () => unsubscribe()
  }, [])

  const handleStatusChange = async (candidateId: string, newStatus: "pendente" | "aceito" | "recusado") => {
    try {
      const candidateRef = ref(database, `candidatos/${candidateId}`)
      await update(candidateRef, { status: newStatus })
    } catch (error) {
      console.error("Error updating candidate status:", error)
      alert("Erro ao atualizar status. Tente novamente.")
    }
  }

  const handleDelete = async () => {
    if (!candidateToDelete) return

    try {
      const candidateRef = ref(database, `candidatos/${candidateToDelete}`)
      await remove(candidateRef)
      setDeleteDialogOpen(false)
      setCandidateToDelete(null)
    } catch (error) {
      console.error("Error deleting candidate:", error)
      alert("Erro ao excluir candidato. Tente novamente.")
    }
  }

  const handleViewDetails = (candidate: Candidate) => {
    setSelectedCandidate(candidate)
    setViewDialogOpen(true)
  }

  const handleSendEmail = (candidate: Candidate) => {
    const subject = encodeURIComponent(`CCTL - Candidatura: ${candidate.cargo}`)
    const body = encodeURIComponent(`Olá ${candidate.nome},\n\n`)
    window.location.href = `mailto:${candidate.email}?subject=${subject}&body=${body}`
  }

  const handleExportCSV = () => {
    const headers = ["Nome", "Email", "Telefone", "Curso de Interesse", "Data de Submissão", "Status"]
    const rows = candidates.map((c) => [
      c.nome,
      c.email,
      c.telefone,
      c.cargo,
      c.submittedAt ? new Date(c.submittedAt).toLocaleString("pt-BR") : "N/A",
      c.status || "pendente",
    ])

    const csvContent = [headers.join(","), ...rows.map((row) => row.map((cell) => `"${cell}"`).join(","))].join("\n")

    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" })
    const link = document.createElement("a")
    const url = URL.createObjectURL(blob)
    link.setAttribute("href", url)
    link.setAttribute("download", `candidatos_cctl_${new Date().toISOString().split("T")[0]}.csv`)
    link.style.visibility = "hidden"
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }

  const getStatusBadge = (status?: string) => {
    switch (status) {
      case "aceito":
        return <Badge className="bg-green-500">Aceito</Badge>
      case "recusado":
        return <Badge variant="destructive">Recusado</Badge>
      default:
        return <Badge variant="secondary">Pendente</Badge>
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-8">
        <Loader2 className="w-8 h-8 animate-spin" />
      </div>
    )
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle>Gerenciar Candidatos</CardTitle>
        {candidates.length > 0 && (
          <Button onClick={handleExportCSV} variant="outline" size="sm">
            <Download className="mr-2 h-4 w-4" />
            Exportar CSV
          </Button>
        )}
      </CardHeader>
      <CardContent>
        {candidates.length > 0 ? (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Nome</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead className="hidden md:table-cell">Telefone</TableHead>
                  <TableHead>Curso</TableHead>
                  <TableHead className="hidden lg:table-cell">Data</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {candidates.map((candidate) => (
                  <TableRow key={candidate.id}>
                    <TableCell className="font-medium">{candidate.nome}</TableCell>
                    <TableCell className="max-w-[200px] truncate">{candidate.email}</TableCell>
                    <TableCell className="hidden md:table-cell">{candidate.telefone}</TableCell>
                    <TableCell className="max-w-[150px] truncate">{candidate.cargo}</TableCell>
                    <TableCell className="hidden lg:table-cell">
                      {candidate.submittedAt ? new Date(candidate.submittedAt).toLocaleDateString("pt-BR") : "N/A"}
                    </TableCell>
                    <TableCell>
                      <Select
                        value={candidate.status || "pendente"}
                        onValueChange={(value) => handleStatusChange(candidate.id, value as any)}
                      >
                        <SelectTrigger className="w-[120px]">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="pendente">
                            <Badge variant="secondary">Pendente</Badge>
                          </SelectItem>
                          <SelectItem value="aceito">
                            <Badge className="bg-green-500">Aceito</Badge>
                          </SelectItem>
                          <SelectItem value="recusado">
                            <Badge variant="destructive">Recusado</Badge>
                          </SelectItem>
                        </SelectContent>
                      </Select>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex gap-2 justify-end flex-wrap">
                        <Button variant="outline" size="sm" onClick={() => handleViewDetails(candidate)}>
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleSendEmail(candidate)}
                          title="Enviar email"
                        >
                          <Mail className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            setCandidateToDelete(candidate.id)
                            setDeleteDialogOpen(true)
                          }}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        ) : (
          <p className="text-center text-muted-foreground py-8">Nenhum candidato cadastrado ainda.</p>
        )}
      </CardContent>

      {/* View Details Dialog */}
      <Dialog open={viewDialogOpen} onOpenChange={setViewDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Detalhes do Candidato</DialogTitle>
            <DialogDescription>Informações completas da candidatura</DialogDescription>
          </DialogHeader>
          {selectedCandidate && (
            <div className="space-y-4">
              <div>
                <h4 className="font-semibold mb-1">Nome</h4>
                <p className="text-muted-foreground">{selectedCandidate.nome}</p>
              </div>
              <div>
                <h4 className="font-semibold mb-1">Email</h4>
                <p className="text-muted-foreground">{selectedCandidate.email}</p>
              </div>
              <div>
                <h4 className="font-semibold mb-1">Telefone</h4>
                <p className="text-muted-foreground">{selectedCandidate.telefone}</p>
              </div>
              <div>
                <h4 className="font-semibold mb-1">Curso de Interesse</h4>
                <p className="text-muted-foreground">{selectedCandidate.cargo}</p>
              </div>
              {selectedCandidate.motivo && (
                <div>
                  <h4 className="font-semibold mb-1">Mensagem</h4>
                  <p className="text-muted-foreground">{selectedCandidate.motivo}</p>
                </div>
              )}
              <div>
                <h4 className="font-semibold mb-1">Data de Submissão</h4>
                <p className="text-muted-foreground">
                  {selectedCandidate.submittedAt
                    ? new Date(selectedCandidate.submittedAt).toLocaleString("pt-BR")
                    : "N/A"}
                </p>
              </div>
              <div>
                <h4 className="font-semibold mb-1">Status</h4>
                {getStatusBadge(selectedCandidate.status)}
              </div>
              <div className="flex gap-2 pt-4">
                <Button className="flex-1" onClick={() => handleSendEmail(selectedCandidate)}>
                  <Mail className="mr-2 h-4 w-4" />
                  Enviar Email
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirmar exclusão</AlertDialogTitle>
            <AlertDialogDescription>
              Tem certeza que deseja excluir este candidato? Esta ação não pode ser desfeita.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete}>Excluir</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </Card>
  )
}
