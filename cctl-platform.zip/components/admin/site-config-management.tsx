"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { database } from "@/lib/firebase-config"
import { ref, onValue, set } from "firebase/database"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Loader2, Save } from "lucide-react"
import { Separator } from "@/components/ui/separator"

interface SiteConfig {
  bannerTitle?: string
  bannerSubtitle?: string
  bannerImage?: string
  aboutTitle?: string
  aboutDescription?: string
  visao?: string
  missao?: string
  valores?: string
  contactEmail?: string
  contactPhone?: string
  contactAddress?: string
  socialFacebook?: string
  socialInstagram?: string
  socialLinkedin?: string
}

export default function SiteConfigManagement() {
  const [loading, setLoading] = useState(true)
  const [submitting, setSubmitting] = useState(false)
  const [config, setConfig] = useState<SiteConfig>({
    bannerTitle: "",
    bannerSubtitle: "",
    bannerImage: "",
    aboutTitle: "",
    aboutDescription: "",
    visao: "",
    missao: "",
    valores: "",
    contactEmail: "",
    contactPhone: "",
    contactAddress: "",
    socialFacebook: "",
    socialInstagram: "",
    socialLinkedin: "",
  })

  useEffect(() => {
    const configRef = ref(database, "site_config")
    const unsubscribe = onValue(configRef, (snapshot) => {
      if (snapshot.exists()) {
        setConfig({ ...config, ...snapshot.val() })
      }
      setLoading(false)
    })

    return () => unsubscribe()
  }, [])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setSubmitting(true)

    try {
      const configRef = ref(database, "site_config")
      await set(configRef, config)
      alert("Configurações salvas com sucesso!")
    } catch (error) {
      console.error("Error saving config:", error)
      alert("Erro ao salvar configurações. Tente novamente.")
    } finally {
      setSubmitting(false)
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-8">
        <Loader2 className="w-8 h-8 animate-spin" />
      </div>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Configurações do Site</CardTitle>
        <CardDescription>Edite as informações exibidas na landing page</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Banner Section */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Banner Principal</h3>
            <div>
              <Label htmlFor="bannerTitle">Título do Banner</Label>
              <Input
                id="bannerTitle"
                value={config.bannerTitle}
                onChange={(e) => setConfig({ ...config, bannerTitle: e.target.value })}
                placeholder="Bem-vindo ao CCTL"
              />
            </div>
            <div>
              <Label htmlFor="bannerSubtitle">Subtítulo do Banner</Label>
              <Input
                id="bannerSubtitle"
                value={config.bannerSubtitle}
                onChange={(e) => setConfig({ ...config, bannerSubtitle: e.target.value })}
                placeholder="Capacitação tecnológica e desenvolvimento de liderança"
              />
            </div>
            <div>
              <Label htmlFor="bannerImage">URL da Imagem do Banner (opcional)</Label>
              <Input
                id="bannerImage"
                type="url"
                value={config.bannerImage}
                onChange={(e) => setConfig({ ...config, bannerImage: e.target.value })}
                placeholder="https://exemplo.com/banner.jpg"
              />
            </div>
          </div>

          <Separator />

          {/* About Section */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Seção Sobre</h3>
            <div>
              <Label htmlFor="aboutTitle">Título da Seção Sobre</Label>
              <Input
                id="aboutTitle"
                value={config.aboutTitle}
                onChange={(e) => setConfig({ ...config, aboutTitle: e.target.value })}
                placeholder="Sobre a CCTL"
              />
            </div>
            <div>
              <Label htmlFor="aboutDescription">Descrição</Label>
              <Textarea
                id="aboutDescription"
                value={config.aboutDescription}
                onChange={(e) => setConfig({ ...config, aboutDescription: e.target.value })}
                rows={6}
                placeholder="Descrição da instituição..."
              />
            </div>
          </div>

          <Separator />

          {/* Vision, Mission, Values Section */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Visão, Missão e Valores</h3>
            <div>
              <Label htmlFor="visao">Visão</Label>
              <Textarea
                id="visao"
                value={config.visao}
                onChange={(e) => setConfig({ ...config, visao: e.target.value })}
                rows={3}
                placeholder="Descreva a visão da instituição..."
              />
            </div>
            <div>
              <Label htmlFor="missao">Missão</Label>
              <Textarea
                id="missao"
                value={config.missao}
                onChange={(e) => setConfig({ ...config, missao: e.target.value })}
                rows={3}
                placeholder="Descreva a missão da instituição..."
              />
            </div>
            <div>
              <Label htmlFor="valores">Valores</Label>
              <Textarea
                id="valores"
                value={config.valores}
                onChange={(e) => setConfig({ ...config, valores: e.target.value })}
                rows={3}
                placeholder="Descreva os valores da instituição..."
              />
            </div>
          </div>

          <Separator />

          {/* Contact Section */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Informações de Contato</h3>
            <div>
              <Label htmlFor="contactEmail">Email</Label>
              <Input
                id="contactEmail"
                type="email"
                value={config.contactEmail}
                onChange={(e) => setConfig({ ...config, contactEmail: e.target.value })}
                placeholder="contato@cctl.com"
              />
            </div>
            <div>
              <Label htmlFor="contactPhone">Telefone</Label>
              <Input
                id="contactPhone"
                type="tel"
                value={config.contactPhone}
                onChange={(e) => setConfig({ ...config, contactPhone: e.target.value })}
                placeholder="(00) 0000-0000"
              />
            </div>
            <div>
              <Label htmlFor="contactAddress">Endereço</Label>
              <Textarea
                id="contactAddress"
                value={config.contactAddress}
                onChange={(e) => setConfig({ ...config, contactAddress: e.target.value })}
                rows={3}
                placeholder="Rua, número, bairro, cidade, estado"
              />
            </div>
          </div>

          <Separator />

          {/* Social Media Section */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Redes Sociais</h3>
            <div>
              <Label htmlFor="socialFacebook">Facebook</Label>
              <Input
                id="socialFacebook"
                type="url"
                value={config.socialFacebook}
                onChange={(e) => setConfig({ ...config, socialFacebook: e.target.value })}
                placeholder="https://facebook.com/cctl"
              />
            </div>
            <div>
              <Label htmlFor="socialInstagram">Instagram</Label>
              <Input
                id="socialInstagram"
                type="url"
                value={config.socialInstagram}
                onChange={(e) => setConfig({ ...config, socialInstagram: e.target.value })}
                placeholder="https://instagram.com/cctl"
              />
            </div>
            <div>
              <Label htmlFor="socialLinkedin">LinkedIn</Label>
              <Input
                id="socialLinkedin"
                type="url"
                value={config.socialLinkedin}
                onChange={(e) => setConfig({ ...config, socialLinkedin: e.target.value })}
                placeholder="https://linkedin.com/company/cctl"
              />
            </div>
          </div>

          <div className="flex justify-end pt-4">
            <Button type="submit" disabled={submitting}>
              {submitting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Salvando...
                </>
              ) : (
                <>
                  <Save className="mr-2 h-4 w-4" />
                  Salvar Configurações
                </>
              )}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  )
}
