"use client"

import { useState, useEffect } from "react"
import { database } from "@/lib/firebase-config"
import { ref, onValue } from "firebase/database"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { Loader2, Search, ArrowLeft } from "lucide-react"
import Image from "next/image"
import Link from "next/link"

interface Candidatura {
  id: string
  nomeCompleto: string
  email: string
  cargo: string
  status: string
  dataSubmissao: string
}

interface StatusMessage {
  id: string
  status: string
  mensagem: string
  link?: string
}

const statusColors = {
  "em análise": "bg-yellow-100 text-yellow-800",
  aceito: "bg-green-100 text-green-800",
  recusado: "bg-red-100 text-red-800",
  entrevista: "bg-blue-100 text-blue-800",
}

export default function StatusCandidaturaPage() {
  const [searchName, setSearchName] = useState("")
  const [candidaturas, setCandidaturas] = useState<Candidatura[]>([])
  const [statusMessages, setStatusMessages] = useState<StatusMessage[]>([])
  const [filteredResults, setFilteredResults] = useState<Candidatura[]>([])
  const [selectedCandidatura, setSelectedCandidatura] = useState<Candidatura | null>(null)
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)

  useEffect(() => {
    // Load candidaturas
    const candidaturasRef = ref(database, "candidaturas")
    const unsubCandidaturas = onValue(candidaturasRef, (snapshot) => {
      if (snapshot.exists()) {
        const data = snapshot.val()
        const candidaturasList = Object.keys(data).map((key) => ({
          id: key,
          ...data[key],
        }))
        setCandidaturas(candidaturasList)
      }
      setLoading(false)
    })

    // Load status messages
    const messagesRef = ref(database, "candidatura_status_messages")
    const unsubMessages = onValue(messagesRef, (snapshot) => {
      if (snapshot.exists()) {
        const data = snapshot.val()
        const messagesList = Object.keys(data).map((key) => ({
          id: key,
          ...data[key],
        }))
        setStatusMessages(messagesList)
      }
    })

    return () => {
      unsubCandidaturas()
      unsubMessages()
    }
  }, [])

  // Search functionality
  useEffect(() => {
    if (searchName.trim()) {
      const filtered = candidaturas.filter((c) => c.nomeCompleto.toLowerCase().includes(searchName.toLowerCase()))
      setFilteredResults(filtered)
    } else {
      setFilteredResults([])
    }
  }, [searchName, candidaturas])

  const getStatusMessage = (status: string) => {
    return statusMessages.find((msg) => msg.status === status)
  }

  const handleViewDetails = (candidatura: Candidatura) => {
    setSelectedCandidatura(candidatura)
    setDialogOpen(true)
  }

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen gap-4">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
        <p className="text-muted-foreground">Carregando dados...</p>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-background sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link
            href="/"
            className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            <span className="text-sm">Voltar</span>
          </Link>
          <div className="flex items-center gap-3">
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/AuealqKvSx2PDBiPOATGAg-removebg-preview-WtroRwh6uTklZcQ0LotaTdHXdU5U6q.png"
              alt="CCTL Logo"
              width={40}
              height={40}
              className="object-contain"
            />
            <div>
              <h1 className="text-lg font-bold">CCTL</h1>
              <p className="text-xs text-muted-foreground hidden sm:block">Status Candidatura</p>
            </div>
          </div>
        </div>
      </header>

      {/* Main Section */}
      <section className="py-12 md:py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-2xl mx-auto">
            <div className="text-center mb-8">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Verificar Status da Candidatura</h2>
              <p className="text-muted-foreground">
                Pesquise seu nome para ver o status de sua candidatura e mensagens do administrador
              </p>
            </div>

            {/* Search Bar */}
            <Card className="mb-8">
              <CardContent className="pt-6">
                <div className="relative flex gap-2">
                  <Search className="absolute left-3 top-3 w-5 h-5 text-muted-foreground" />
                  <Input
                    placeholder="Digite seu nome completo..."
                    value={searchName}
                    onChange={(e) => setSearchName(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </CardContent>
            </Card>

            {/* Results */}
            {searchName.trim() && (
              <div className="space-y-4">
                {filteredResults.length > 0 ? (
                  filteredResults.map((candidatura) => {
                    const statusMsg = getStatusMessage(candidatura.status)
                    return (
                      <Card
                        key={candidatura.id}
                        className="hover:shadow-lg transition-shadow cursor-pointer"
                        onClick={() => handleViewDetails(candidatura)}
                      >
                        <CardHeader>
                          <div className="flex items-start justify-between gap-4">
                            <div>
                              <CardTitle>{candidatura.nomeCompleto}</CardTitle>
                              <CardDescription>{candidatura.cargo}</CardDescription>
                            </div>
                            <Badge className={statusColors[candidatura.status as keyof typeof statusColors]}>
                              {candidatura.status}
                            </Badge>
                          </div>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-2">
                            <p className="text-sm text-muted-foreground">
                              <span className="font-medium">Email:</span> {candidatura.email}
                            </p>
                            <p className="text-sm text-muted-foreground">
                              <span className="font-medium">Data de Candidatura:</span>{" "}
                              {new Date(candidatura.dataSubmissao).toLocaleDateString("pt-BR")}
                            </p>
                            {statusMsg && (
                              <div className="mt-3 p-3 bg-muted rounded">
                                <p className="text-sm font-medium mb-1">Mensagem do Administrador:</p>
                                <p className="text-sm text-foreground">{statusMsg.mensagem}</p>
                                {statusMsg.link && (
                                  <a
                                    href={statusMsg.link}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className="text-sm text-primary hover:underline mt-2 inline-block"
                                  >
                                    Ver mais informações →
                                  </a>
                                )}
                              </div>
                            )}
                          </div>
                        </CardContent>
                      </Card>
                    )
                  })
                ) : (
                  <Card>
                    <CardContent className="pt-6 text-center">
                      <p className="text-muted-foreground">Nenhuma candidatura encontrada com esse nome.</p>
                    </CardContent>
                  </Card>
                )}
              </div>
            )}

            {!searchName.trim() && (
              <Card>
                <CardContent className="pt-6 text-center">
                  <p className="text-muted-foreground">Digite seu nome acima para pesquisar sua candidatura.</p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </section>

      {/* Details Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl">
          {selectedCandidatura && (
            <>
              <DialogHeader>
                <DialogTitle>{selectedCandidatura.nomeCompleto}</DialogTitle>
                <DialogDescription>Detalhes da candidatura</DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <p className="font-semibold text-sm text-muted-foreground">CARGO DESEJADO</p>
                  <p className="text-lg">{selectedCandidatura.cargo}</p>
                </div>
                <div>
                  <p className="font-semibold text-sm text-muted-foreground">EMAIL</p>
                  <p className="text-lg">{selectedCandidatura.email}</p>
                </div>
                <div>
                  <p className="font-semibold text-sm text-muted-foreground">STATUS</p>
                  <Badge className={`${statusColors[selectedCandidatura.status as keyof typeof statusColors]} mt-1`}>
                    {selectedCandidatura.status}
                  </Badge>
                </div>
                <div>
                  <p className="font-semibold text-sm text-muted-foreground">DATA DA CANDIDATURA</p>
                  <p className="text-lg">{new Date(selectedCandidatura.dataSubmissao).toLocaleDateString("pt-BR")}</p>
                </div>

                {/* Status Message */}
                {getStatusMessage(selectedCandidatura.status) && (
                  <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                    <p className="font-semibold text-sm mb-2">Mensagem do Administrador:</p>
                    <p className="text-foreground">{getStatusMessage(selectedCandidatura.status)?.mensagem}</p>
                    {getStatusMessage(selectedCandidatura.status)?.link && (
                      <a
                        href={getStatusMessage(selectedCandidatura.status)?.link}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-primary hover:underline mt-2 inline-block text-sm"
                      >
                        Ver mais informações →
                      </a>
                    )}
                  </div>
                )}
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
