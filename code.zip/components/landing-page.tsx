"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { database } from "@/lib/firebase-config"
import { ref, onValue, push } from "firebase/database"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import {
  Loader2,
  AlertCircle,
  Target,
  Eye,
  Award,
  MapPin,
  Phone,
  Facebook,
  Instagram,
  Linkedin,
  Share2,
} from "lucide-react"
import Image from "next/image"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from "@/components/ui/carousel"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog"
import Link from "next/link"

interface SiteConfig {
  bannerTitle?: string
  bannerSubtitle?: string
  bannerImages?: string[]
  aboutTitle?: string
  aboutDescription?: string
  visao?: string
  missao?: string
  valores?: string
  contactEmail?: string
  contactPhone?: string
  contactAddress?: string
  socialFacebook?: string
  socialInstagram?: string
  socialLinkedin?: string
}

interface Course {
  id: string
  name: string
  description: string
  resumo?: string
  image?: string
  vagasDisponiveis?: number
  status: "ativo" | "inativo"
}

interface Publication {
  id: string
  title: string
  content: string
  resumo?: string
  image?: string
  date: string
}

export default function LandingPage() {
  const [siteConfig, setSiteConfig] = useState<SiteConfig>({})
  const [courses, setCourses] = useState<Course[]>([])
  const [publications, setPublications] = useState<Publication[]>([])
  const [loading, setLoading] = useState(true)
  const [submitting, setSubmitting] = useState(false)
  const [submissionError, setSubmissionError] = useState<string | null>(null)
  const [selectedCourse, setSelectedCourse] = useState<Course | null>(null)
  const [selectedPublication, setSelectedPublication] = useState<Publication | null>(null)
  const [currentBannerIndex, setCurrentBannerIndex] = useState(0)

  useEffect(() => {
    const loadingTimeout = setTimeout(() => {
      setLoading(false)
    }, 3000)

    // Load site configuration
    const configRef = ref(database, "site_config")
    const unsubConfig = onValue(
      configRef,
      (snapshot) => {
        if (snapshot.exists()) {
          setSiteConfig(snapshot.val())
        }
        clearTimeout(loadingTimeout)
        setLoading(false)
      },
      (error) => {
        console.error("[v0] Error loading site config:", error)
        clearTimeout(loadingTimeout)
        setLoading(false)
      },
    )

    // Load courses
    const coursesRef = ref(database, "cursos")
    const unsubCourses = onValue(
      coursesRef,
      (snapshot) => {
        if (snapshot.exists()) {
          const data = snapshot.val()
          const coursesList = Object.keys(data)
            .map((key) => ({
              id: key,
              ...data[key],
            }))
            .filter((course) => course.status === "ativo")
          setCourses(coursesList)
        }
      },
      (error) => {
        console.error("[v0] Error loading courses:", error)
      },
    )

    // Load publications
    const publicationsRef = ref(database, "publicacoes")
    const unsubPublications = onValue(
      publicationsRef,
      (snapshot) => {
        if (snapshot.exists()) {
          const data = snapshot.val()
          const publicationsList = Object.keys(data)
            .map((key) => ({
              id: key,
              ...data[key],
            }))
            .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
          setPublications(publicationsList)
        }
      },
      (error) => {
        console.error("[v0] Error loading publications:", error)
      },
    )

    const bannerTimer = setInterval(() => {
      const images = siteConfig.bannerImages || []
      if (images.length > 1) {
        setCurrentBannerIndex((prev) => (prev + 1) % images.length)
      }
    }, 5000)

    return () => {
      clearTimeout(loadingTimeout)
      clearInterval(bannerTimer)
      unsubConfig()
      unsubCourses()
      unsubPublications()
    }
  }, [siteConfig.bannerImages])

  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    course: "",
    message: "",
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setSubmitting(true)
    setSubmissionError(null)

    if (formData.message.length < 10) {
      setSubmissionError("A mensagem deve ter pelo menos 10 caracteres.")
      setSubmitting(false)
      return
    }

    try {
      const candidatosRef = ref(database, "candidatos")
      await push(candidatosRef, {
        nome: formData.name,
        email: formData.email,
        telefone: formData.phone,
        cargo: formData.course,
        motivo: formData.message,
      })

      alert("Candidatura enviada com sucesso!")
      setFormData({
        name: "",
        email: "",
        phone: "",
        course: "",
        message: "",
      })
    } catch (error: any) {
      console.error("[v0] Erro ao enviar candidatura:", error)
      setSubmissionError("Erro ao enviar candidatura. Por favor, tente novamente ou entre em contato conosco.")
    } finally {
      setSubmitting(false)
    }
  }

  const scrollToForm = () => {
    document.getElementById("inscricao")?.scrollIntoView({ behavior: "smooth" })
  }

  const handleShareContent = (type: "course" | "publication", id: string, title: string, content: string) => {
    const deepLink = `${window.location.origin}?${type}=${id}`
    const shareText = `${title}\n${content.substring(0, 100)}...\n${deepLink}`
    const encodedText = encodeURIComponent(shareText)
    const encodedUrl = encodeURIComponent(deepLink)

    if (navigator.share) {
      navigator
        .share({
          title: title,
          text: content.substring(0, 100),
          url: deepLink,
        })
        .catch((err) => console.log("[v0] Share cancelled or error:", err))
    } else {
      const shareWindow = window.open("", "share", "width=600,height=600")
      if (shareWindow) {
        shareWindow.document.write(`
          <!DOCTYPE html>
          <html lang="pt-BR">
          <head>
            <meta charset="UTF-8">
            <title>Compartilhar</title>
            <style>
              body { font-family: Arial; padding: 20px; background: #f5f5f5; }
              .container { max-width: 500px; margin: 0 auto; background: white; padding: 20px; border-radius: 8px; }
              h2 { color: #333; }
              a { display: block; margin: 10px 0; padding: 10px; background: #007bff; color: white; text-decoration: none; border-radius: 4px; text-align: center; }
              a:hover { background: #0056b3; }
            </style>
          </head>
          <body>
            <div class="container">
              <h2>Compartilhar</h2>
              <a href="https://www.facebook.com/sharer/sharer.php?u=${encodedUrl}" target="_blank">Compartilhar no Facebook</a>
              <a href="https://wa.me/?text=${encodedText}" target="_blank">Compartilhar no WhatsApp</a>
              <a href="https://twitter.com/intent/tweet?text=${encodedText}" target="_blank">Compartilhar no Twitter</a>
              <a href="https://www.linkedin.com/sharing/share-offsite/?url=${encodedUrl}" target="_blank">Compartilhar no LinkedIn</a>
            </div>
          </body>
          </html>
        `)
      }
    }
  }

  useEffect(() => {
    const params = new URLSearchParams(window.location.search)
    const courseId = params.get("course")
    const publicationId = params.get("publication")

    if (courseId && courses.length > 0) {
      const course = courses.find((c) => c.id === courseId)
      if (course) {
        setSelectedCourse(course)
      }
    }

    if (publicationId && publications.length > 0) {
      const publication = publications.find((p) => p.id === publicationId)
      if (publication) {
        setSelectedPublication(publication)
      }
    }
  }, [courses, publications])

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen gap-4">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
        <p className="text-muted-foreground">Carregando plataforma CCTL...</p>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      {/* ... existing header code ... */}
      <header className="border-b sticky top-0 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/AuealqKvSx2PDBiPOATGAg-removebg-preview-WtroRwh6uTklZcQ0LotaTdHXdU5U6q.png"
              alt="CCTL Logo"
              width={50}
              height={50}
              className="object-contain"
            />
            <div>
              <h1 className="text-xl font-bold">CCTL</h1>
              <p className="text-xs text-muted-foreground">Centro de Capacitação Tecnológica e Liderança</p>
            </div>
          </div>
          <nav className="hidden md:flex gap-6">
            <a href="#sobre" className="hover:text-primary transition-colors">
              Sobre
            </a>
            <a href="#cursos" className="hover:text-primary transition-colors">
              Cursos
            </a>
            <a href="#publicacoes" className="hover:text-primary transition-colors">
              Publicações
            </a>
            <a href="#inscricao" className="hover:text-primary transition-colors">
              Inscrição
            </a>
            <Link href="/candidatura" className="hover:text-primary transition-colors">
              Candidatura
            </Link>
            <Link href="/status-candidatura" className="hover:text-primary transition-colors">
              Ver Status
            </Link>
          </nav>
        </div>
      </header>

      <section className="relative bg-gradient-to-br from-blue-600 to-blue-800 text-white py-20 md:py-32 overflow-hidden">
        {siteConfig.bannerImages && siteConfig.bannerImages.length > 0 && (
          <div className="absolute inset-0 z-0">
            <img
              src={siteConfig.bannerImages[currentBannerIndex] || "/placeholder.svg"}
              alt="Banner"
              className="w-full h-full object-cover opacity-30"
            />
          </div>
        )}
        <div className="container mx-auto px-4 text-center relative z-10">
          <h2 className="text-4xl md:text-6xl font-bold mb-4 text-balance">
            {siteConfig.bannerTitle || "Bem-vindo ao CCTL"}
          </h2>
          <p className="text-xl md:text-2xl text-blue-100 max-w-3xl mx-auto text-balance">
            {siteConfig.bannerSubtitle || "Capacitação tecnológica e desenvolvimento de liderança"}
          </p>
          <Button size="lg" className="mt-8 bg-white text-blue-800 hover:bg-blue-50" onClick={scrollToForm}>
            Inscreva-se Agora
          </Button>
        </div>
      </section>

      {/* ... existing about section ... */}
      <section id="sobre" className="py-16 md:py-24">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">{siteConfig.aboutTitle || "Sobre a CCTL"}</h2>
            <p className="text-lg text-muted-foreground leading-relaxed">
              {siteConfig.aboutDescription ||
                "O Centro de Capacitação Tecnológica e Liderança é uma instituição dedicada ao desenvolvimento de profissionais através de cursos e programas de capacitação em tecnologia e liderança."}
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto mt-12">
            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="mx-auto w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mb-4">
                  <Eye className="w-8 h-8 text-blue-600" />
                </div>
                <CardTitle>Visão</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  {siteConfig.visao ||
                    "Ser referência em capacitação tecnológica e desenvolvimento de liderança na região."}
                </p>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="mx-auto w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-4">
                  <Target className="w-8 h-8 text-green-600" />
                </div>
                <CardTitle>Missão</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  {siteConfig.missao ||
                    "Capacitar profissionais com conhecimentos tecnológicos e habilidades de liderança para o mercado de trabalho."}
                </p>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="mx-auto w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mb-4">
                  <Award className="w-8 h-8 text-purple-600" />
                </div>
                <CardTitle>Valores</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  {siteConfig.valores ||
                    "Excelência, inovação, ética, compromisso com o desenvolvimento humano e profissional."}
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* ... existing cursos section ... */}
      <section id="cursos" className="py-16 md:py-24 bg-muted/50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">Nossos Cursos</h2>
          {courses.length > 0 ? (
            <div className="max-w-4xl mx-auto">
              <Carousel className="w-full">
                <CarouselContent>
                  {courses.map((course) => (
                    <CarouselItem key={course.id}>
                      <Card
                        className="overflow-hidden hover:shadow-lg transition-shadow cursor-pointer"
                        onClick={() => setSelectedCourse(course)}
                      >
                        {course.image && (
                          <div className="relative h-64 bg-muted">
                            <Image
                              src={course.image || "/placeholder.svg"}
                              alt={course.name}
                              fill
                              className="object-cover"
                            />
                          </div>
                        )}
                        <CardHeader>
                          <CardTitle className="text-2xl">{course.name}</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <p className="text-muted-foreground">{course.resumo || course.description}</p>
                          <Button className="mt-4 w-full bg-transparent" variant="outline">
                            Ver Detalhes
                          </Button>
                        </CardContent>
                      </Card>
                    </CarouselItem>
                  ))}
                </CarouselContent>
                <CarouselPrevious />
                <CarouselNext />
              </Carousel>
            </div>
          ) : (
            <div className="text-center py-12">
              <p className="text-muted-foreground mb-2">Nenhum curso disponível no momento.</p>
              <p className="text-sm text-muted-foreground">Os cursos serão adicionados pelo administrador em breve.</p>
            </div>
          )}
        </div>
      </section>

      <Dialog open={!!selectedCourse} onOpenChange={() => setSelectedCourse(null)}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          {selectedCourse && (
            <>
              {selectedCourse.image && (
                <div className="relative h-64 w-full -mx-6 -mt-6 mb-4">
                  <Image
                    src={selectedCourse.image || "/placeholder.svg"}
                    alt={selectedCourse.name}
                    fill
                    className="object-cover"
                  />
                </div>
              )}
              <DialogHeader>
                <DialogTitle className="text-2xl">{selectedCourse.name}</DialogTitle>
              </DialogHeader>
              <DialogDescription className="text-base text-foreground">{selectedCourse.description}</DialogDescription>
              {selectedCourse.vagasDisponiveis !== undefined && (
                <div className="bg-muted p-4 rounded-lg">
                  <p className="font-semibold">
                    Vagas Disponíveis: <span className="text-primary">{selectedCourse.vagasDisponiveis}</span>
                  </p>
                </div>
              )}
              <DialogFooter className="flex-col gap-2">
                <Button
                  onClick={() =>
                    handleShareContent("course", selectedCourse.id, selectedCourse.name, selectedCourse.description)
                  }
                  variant="outline"
                  className="w-full"
                >
                  <Share2 className="mr-2 h-4 w-4" />
                  Partilhar
                </Button>
                <Button
                  onClick={() => {
                    setSelectedCourse(null)
                    scrollToForm()
                  }}
                  className="w-full"
                >
                  Inscrever-se
                </Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>

      {/* ... existing publicações section ... */}
      <section id="publicacoes" className="py-16 md:py-24">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">Publicações e Notícias</h2>
          {publications.length > 0 ? (
            <div className="max-w-4xl mx-auto">
              <Carousel className="w-full">
                <CarouselContent>
                  {publications.map((publication) => (
                    <CarouselItem key={publication.id}>
                      <Card
                        className="overflow-hidden hover:shadow-lg transition-shadow cursor-pointer"
                        onClick={() => setSelectedPublication(publication)}
                      >
                        {publication.image && (
                          <div className="relative h-64 bg-muted">
                            <Image
                              src={publication.image || "/placeholder.svg"}
                              alt={publication.title}
                              fill
                              className="object-cover"
                            />
                          </div>
                        )}
                        <CardHeader>
                          <CardTitle className="text-2xl">{publication.title}</CardTitle>
                          <CardDescription className="text-base">
                            {new Date(publication.date).toLocaleDateString("pt-BR")}
                          </CardDescription>
                        </CardHeader>
                        <CardContent>
                          <p className="text-muted-foreground">
                            {publication.resumo || publication.content.substring(0, 150) + "..."}
                          </p>
                          <Button className="mt-4 w-full bg-transparent" variant="outline">
                            Ler Mais
                          </Button>
                        </CardContent>
                      </Card>
                    </CarouselItem>
                  ))}
                </CarouselContent>
                <CarouselPrevious />
                <CarouselNext />
              </Carousel>
            </div>
          ) : (
            <div className="text-center py-12">
              <p className="text-muted-foreground mb-2">Nenhuma publicação disponível no momento.</p>
              <p className="text-sm text-muted-foreground">
                As publicações serão adicionadas pelo administrador em breve.
              </p>
            </div>
          )}
        </div>
      </section>

      <Dialog open={!!selectedPublication} onOpenChange={() => setSelectedPublication(null)}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          {selectedPublication && (
            <>
              {selectedPublication.image && (
                <div className="relative h-64 w-full -mx-6 -mt-6 mb-4">
                  <Image
                    src={selectedPublication.image || "/placeholder.svg"}
                    alt={selectedPublication.title}
                    fill
                    className="object-cover"
                  />
                </div>
              )}
              <DialogHeader>
                <DialogTitle className="text-2xl">{selectedPublication.title}</DialogTitle>
                <DialogDescription>
                  {new Date(selectedPublication.date).toLocaleDateString("pt-BR", {
                    day: "numeric",
                    month: "long",
                    year: "numeric",
                  })}
                </DialogDescription>
              </DialogHeader>
              <div className="text-base text-foreground whitespace-pre-wrap">{selectedPublication.content}</div>
              <DialogFooter>
                <Button
                  onClick={() =>
                    handleShareContent(
                      "publication",
                      selectedPublication.id,
                      selectedPublication.title,
                      selectedPublication.content,
                    )
                  }
                  variant="outline"
                  className="w-full"
                >
                  <Share2 className="mr-2 h-4 w-4" />
                  Partilhar
                </Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>

      {/* ... existing inscricao section ... */}
      <section id="inscricao" className="py-16 md:py-24 bg-muted/50">
        <div className="container mx-auto px-4">
          <div className="max-w-2xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-bold text-center mb-4">Inscreva-se</h2>
            <p className="text-center text-muted-foreground mb-8">
              Preencha o formulário abaixo para se inscrever nos nossos cursos
            </p>

            {submissionError && (
              <Alert variant="destructive" className="mb-6">
                <AlertCircle className="h-4 w-4" />
                <AlertTitle>Erro ao enviar inscrição</AlertTitle>
                <AlertDescription>{submissionError}</AlertDescription>
              </Alert>
            )}

            <Card>
              <CardContent className="pt-6">
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <Label htmlFor="name">Nome Completo</Label>
                    <Input
                      id="name"
                      required
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    />
                  </div>
                  <div>
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      required
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    />
                  </div>
                  <div>
                    <Label htmlFor="phone">Telefone</Label>
                    <Input
                      id="phone"
                      type="tel"
                      required
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    />
                  </div>
                  <div>
                    <Label htmlFor="course">Curso de Interesse</Label>
                    <select
                      id="course"
                      required
                      value={formData.course}
                      onChange={(e) => setFormData({ ...formData, course: e.target.value })}
                      className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                    >
                      <option value="">Selecione um curso</option>
                      {courses.map((course) => (
                        <option key={course.id} value={course.name}>
                          {course.name}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <Label htmlFor="message">Mensagem (mínimo 10 caracteres)</Label>
                    <Textarea
                      id="message"
                      required
                      minLength={10}
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      rows={4}
                      placeholder="Por que você deseja participar deste curso? (mínimo 10 caracteres)"
                    />
                  </div>
                  <Button type="submit" className="w-full" disabled={submitting}>
                    {submitting ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Enviando...
                      </>
                    ) : (
                      "Enviar Inscrição"
                    )}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* ... existing footer ... */}
      <footer className="bg-gradient-to-br from-slate-900 to-slate-800 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div className="md:col-span-1">
              <div className="flex items-center gap-3 mb-4">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/AuealqKvSx2PDBiPOATGAg-removebg-preview-WtroRwh6uTklZcQ0LotaTdHXdU5U6q.png"
                  alt="CCTL Logo"
                  width={60}
                  height={60}
                  className="object-contain"
                />
                <div>
                  <h3 className="font-bold text-lg">CCTL</h3>
                  <p className="text-xs text-slate-300">Centro de Capacitação Tecnológica e Liderança</p>
                </div>
              </div>
            </div>

            <div>
              <h3 className="font-bold mb-4 text-lg">Links Rápidos</h3>
              <ul className="space-y-2">
                <li>
                  <a href="#sobre" className="text-slate-300 hover:text-white transition-colors text-sm">
                    Sobre Nós
                  </a>
                </li>
                <li>
                  <a href="#cursos" className="text-slate-300 hover:text-white transition-colors text-sm">
                    Cursos
                  </a>
                </li>
                <li>
                  <a href="#publicacoes" className="text-slate-300 hover:text-white transition-colors text-sm">
                    Publicações
                  </a>
                </li>
                <li>
                  <a href="#inscricao" className="text-slate-300 hover:text-white transition-colors text-sm">
                    Inscrição
                  </a>
                </li>
                <li>
                  <Link href="/candidatura" className="text-slate-300 hover:text-white transition-colors text-sm">
                    Candidatura
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="font-bold mb-4 text-lg">Contato</h3>
              <div className="space-y-3">
                <div className="flex items-start gap-2">
                  <MapPin className="w-4 h-4 mt-1 flex-shrink-0 text-slate-300" />
                  <p className="text-sm text-slate-300">{siteConfig.contactAddress || "Endereço não disponível"}</p>
                </div>
                <div className="flex items-center gap-2">
                  <Phone className="w-4 h-4 flex-shrink-0 text-slate-300" />
                  <p className="text-sm text-slate-300">{siteConfig.contactPhone || "(00) 0000-0000"}</p>
                </div>
                <div className="flex items-center gap-2">
                  <svg
                    className="w-4 h-4 flex-shrink-0 text-slate-300"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"
                    />
                  </svg>
                  <p className="text-sm text-slate-300">{siteConfig.contactEmail || "contato@cctl.com"}</p>
                </div>
              </div>
            </div>

            <div>
              <h3 className="font-bold mb-4 text-lg">Redes Sociais</h3>
              <div className="flex gap-4">
                {siteConfig.socialFacebook && (
                  <a
                    href={siteConfig.socialFacebook}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-10 h-10 bg-slate-700 hover:bg-blue-600 rounded-full flex items-center justify-center transition-colors"
                    aria-label="Facebook"
                  >
                    <Facebook className="w-5 h-5" />
                  </a>
                )}
                {siteConfig.socialInstagram && (
                  <a
                    href={siteConfig.socialInstagram}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-10 h-10 bg-slate-700 hover:bg-pink-600 rounded-full flex items-center justify-center transition-colors"
                    aria-label="Instagram"
                  >
                    <Instagram className="w-5 h-5" />
                  </a>
                )}
                {siteConfig.socialLinkedin && (
                  <a
                    href={siteConfig.socialLinkedin}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-10 h-10 bg-slate-700 hover:bg-blue-700 rounded-full flex items-center justify-center transition-colors"
                    aria-label="LinkedIn"
                  >
                    <Linkedin className="w-5 h-5" />
                  </a>
                )}
              </div>
            </div>
          </div>

          <div className="pt-8 border-t border-slate-700 text-center">
            <p className="text-sm text-slate-400">
              © {new Date().getFullYear()} CCTL - Centro de Capacitação Tecnológica e Liderança. Todos os direitos
              reservados.
            </p>
          </div>
        </div>
      </footer>
    </div>
  )
}
