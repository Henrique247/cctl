"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { database } from "@/lib/firebase-config"
import { ref, onValue, set, remove } from "firebase/database"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Plus, Pencil, Trash2, Loader2, AlertCircle } from "lucide-react"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { Alert, AlertDescription } from "@/components/ui/alert"

interface StatusMessage {
  id: string
  status: string
  mensagem: string
  link?: string
}

const STATUS_OPTIONS = ["em análise", "aceito", "recusado", "entrevista"]

export default function CandidaturaStatusMessages() {
  const [messages, setMessages] = useState<StatusMessage[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [editingMessage, setEditingMessage] = useState<StatusMessage | null>(null)
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false)
  const [messageToDelete, setMessageToDelete] = useState<string | null>(null)
  const [submitting, setSubmitting] = useState(false)

  const [formData, setFormData] = useState({
    status: "",
    mensagem: "",
    link: "",
  })

  useEffect(() => {
    const messagesRef = ref(database, "candidatura_status_messages")
    const unsubscribe = onValue(
      messagesRef,
      (snapshot) => {
        try {
          console.log("[v0] Loaded candidatura_status_messages:", snapshot.val())
          if (snapshot.exists()) {
            const data = snapshot.val()
            const messagesList = Object.keys(data).map((key) => ({
              id: key,
              ...data[key],
            }))
            setMessages(messagesList)
            setError(null)
          } else {
            setMessages([])
            setError(null)
          }
        } catch (err) {
          console.error("[v0] Error loading messages:", err)
          setError("Erro ao carregar mensagens")
        }
        setLoading(false)
      },
      (error) => {
        console.error("[v0] Firebase error loading messages:", error)
        setError(`Erro do Firebase: ${error.message}`)
        setLoading(false)
      },
    )

    return () => unsubscribe()
  }, [])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setSubmitting(true)
    setError(null)

    if (!formData.status || !formData.mensagem) {
      setError("Por favor, preencha os campos obrigatórios")
      setSubmitting(false)
      return
    }

    try {
      const messageRef = ref(database, `candidatura_status_messages/${formData.status}`)

      const dataToSave: any = {
        status: formData.status,
        mensagem: formData.mensagem,
      }

      // Only add link if it has a value
      if (formData.link && formData.link.trim()) {
        dataToSave.link = formData.link.trim()
      }

      await set(messageRef, dataToSave)

      console.log("[v0] Message saved successfully")
      setDialogOpen(false)
      resetForm()
    } catch (error: any) {
      console.error("[v0] Error saving message:", error)
      setError(`Erro ao salvar mensagem: ${error.message}`)
    } finally {
      setSubmitting(false)
    }
  }

  const handleEdit = (message: StatusMessage) => {
    setEditingMessage(message)
    setFormData({
      status: message.status,
      mensagem: message.mensagem,
      link: message.link || "",
    })
    setDialogOpen(true)
  }

  const handleDelete = async () => {
    if (!messageToDelete) return

    try {
      const messageRef = ref(database, `candidatura_status_messages/${messageToDelete}`)
      await remove(messageRef)
      setDeleteDialogOpen(false)
      setMessageToDelete(null)
      setError(null)
    } catch (error: any) {
      console.error("[v0] Error deleting message:", error)
      setError(`Erro ao excluir mensagem: ${error.message}`)
    }
  }

  const resetForm = () => {
    setFormData({
      status: "",
      mensagem: "",
      link: "",
    })
    setEditingMessage(null)
  }

  const handleDialogClose = () => {
    setDialogOpen(false)
    resetForm()
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-8">
        <Loader2 className="w-8 h-8 animate-spin" />
      </div>
    )
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0">
        <div>
          <CardTitle>Mensagens de Status de Candidatura</CardTitle>
          <CardDescription>
            Configure mensagens e links para cada status de candidatura que os candidatos verão
          </CardDescription>
        </div>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => resetForm()}>
              <Plus className="mr-2 h-4 w-4" />
              Nova Mensagem
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>{editingMessage ? "Editar Mensagem" : "Nova Mensagem de Status"}</DialogTitle>
              <DialogDescription>
                Configure a mensagem que será exibida aos candidatos com este status
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="status">Status *</Label>
                <select
                  id="status"
                  required
                  value={formData.status}
                  onChange={(e) => setFormData({ ...formData, status: e.target.value })}
                  disabled={!!editingMessage}
                  className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                >
                  <option value="">Selecione um status</option>
                  {STATUS_OPTIONS.map((status) => (
                    <option key={status} value={status}>
                      {status.charAt(0).toUpperCase() + status.slice(1)}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <Label htmlFor="mensagem">Mensagem *</Label>
                <Textarea
                  id="mensagem"
                  required
                  value={formData.mensagem}
                  onChange={(e) => setFormData({ ...formData, mensagem: e.target.value })}
                  rows={4}
                  placeholder="Digite a mensagem que será exibida aos candidatos..."
                />
              </div>
              <div>
                <Label htmlFor="link">Link (Opcional)</Label>
                <Input
                  id="link"
                  type="url"
                  value={formData.link}
                  onChange={(e) => setFormData({ ...formData, link: e.target.value })}
                  placeholder="https://exemplo.com"
                />
              </div>
              <div className="flex gap-2 justify-end">
                <Button type="button" variant="outline" onClick={handleDialogClose}>
                  Cancelar
                </Button>
                <Button type="submit" disabled={submitting}>
                  {submitting ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Salvando...
                    </>
                  ) : (
                    "Salvar"
                  )}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </CardHeader>
      <CardContent className="space-y-4">
        {error && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {messages.length > 0 ? (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Status</TableHead>
                <TableHead>Mensagem</TableHead>
                <TableHead className="text-right">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {messages.map((message) => (
                <TableRow key={message.id}>
                  <TableCell className="font-medium">
                    {message.status.charAt(0).toUpperCase() + message.status.slice(1)}
                  </TableCell>
                  <TableCell className="max-w-md truncate">{message.mensagem}</TableCell>
                  <TableCell className="text-right">
                    <div className="flex gap-2 justify-end">
                      <Button variant="outline" size="sm" onClick={() => handleEdit(message)}>
                        <Pencil className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          setMessageToDelete(message.id)
                          setDeleteDialogOpen(true)
                        }}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        ) : (
          <p className="text-center text-muted-foreground py-8">Nenhuma mensagem cadastrada. Crie uma para começar.</p>
        )}
      </CardContent>

      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirmar exclusão</AlertDialogTitle>
            <AlertDialogDescription>
              Tem certeza que deseja excluir esta mensagem? Esta ação não pode ser desfeita.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete}>Excluir</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </Card>
  )
}
