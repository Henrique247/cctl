"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { ImageIcon, LinkIcon, Upload, Loader2 } from "lucide-react"

interface ImageGalleryProps {
  onSelectImage: (url: string) => void
  selectedImage?: string
}

// Pre-configured gallery of example images
const GALLERY_IMAGES = [
  "https://images.unsplash.com/photo-1552664730-d307ca884978?w=400&h=300&fit=crop",
  "https://images.unsplash.com/photo-1552664730-d307ca884978?w=400&h=300&fit=crop",
  "https://images.unsplash.com/photo-1552664730-d307ca884978?w=400&h=300&fit=crop",
  "https://images.unsplash.com/photo-1521737711867-e3b97375f902?w=400&h=300&fit=crop",
  "https://images.unsplash.com/photo-1552664730-d307ca884978?w=400&h=300&fit=crop",
  "https://images.unsplash.com/photo-1552664730-d307ca884978?w=400&h=300&fit=crop",
  "https://images.unsplash.com/photo-1516321318423-f06f70991c72?w=400&h=300&fit=crop",
  "https://images.unsplash.com/photo-1522202176988-08fa0eec1d75?w=400&h=300&fit=crop",
  "https://images.unsplash.com/photo-1552664730-d307ca884978?w=400&h=300&fit=crop",
]

export default function ImageGallery({ onSelectImage, selectedImage }: ImageGalleryProps) {
  const [urlInput, setUrlInput] = useState("")
  const [uploading, setUploading] = useState(false)

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    setUploading(true)
    try {
      const formData = new FormData()
      formData.append("file", file)

      const response = await fetch("/api/upload", {
        method: "POST",
        body: formData,
      })

      if (!response.ok) throw new Error("Upload failed")

      const data = await response.json()
      onSelectImage(data.url)
    } catch (error) {
      console.error("[v0] Upload error:", error)
      alert("Erro ao fazer upload da imagem. Tente novamente.")
    } finally {
      setUploading(false)
    }
  }

  const handleSelectFromGallery = (url: string) => {
    onSelectImage(url)
  }

  const handleUrlSubmit = () => {
    if (urlInput.trim()) {
      onSelectImage(urlInput.trim())
      setUrlInput("")
    }
  }

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="outline" type="button">
          <ImageIcon className="mr-2 h-4 w-4" />
          Selecionar Imagem
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Selecionar Imagem</DialogTitle>
        </DialogHeader>
        <Tabs defaultValue="gallery" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="gallery">
              <ImageIcon className="mr-2 h-4 w-4" />
              Galeria
            </TabsTrigger>
            <TabsTrigger value="upload">
              <Upload className="mr-2 h-4 w-4" />
              Upload
            </TabsTrigger>
            <TabsTrigger value="url">
              <LinkIcon className="mr-2 h-4 w-4" />
              URL
            </TabsTrigger>
          </TabsList>

          <TabsContent value="gallery" className="space-y-4">
            <div className="grid grid-cols-3 gap-4">
              {GALLERY_IMAGES.map((url, index) => (
                <div
                  key={index}
                  onClick={() => handleSelectFromGallery(url)}
                  className={`cursor-pointer rounded-lg overflow-hidden border-2 transition-all hover:border-primary ${
                    selectedImage === url ? "border-primary" : "border-muted"
                  }`}
                >
                  <div className="relative w-full aspect-square">
                    <img
                      src={url || "/placeholder.svg"}
                      alt={`Galeria ${index + 1}`}
                      className="w-full h-full object-cover hover:opacity-80 transition-opacity"
                    />
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="upload" className="space-y-4">
            <div>
              <Label htmlFor="fileUpload">Fazer Upload de Imagem</Label>
              <div className="flex gap-2 mt-2">
                <Input id="fileUpload" type="file" accept="image/*" onChange={handleFileUpload} disabled={uploading} />
                {uploading && <Loader2 className="h-10 w-10 animate-spin" />}
              </div>
              <p className="text-xs text-muted-foreground mt-2">Formatos aceitos: JPG, PNG, WebP. Máximo 5MB.</p>
            </div>
            {selectedImage && selectedImage.startsWith("blob:") && (
              <div>
                <p className="text-sm font-medium mb-2">Pré-visualização:</p>
                <div className="relative w-full aspect-video rounded-lg overflow-hidden border">
                  <img
                    src={selectedImage || "/placeholder.svg"}
                    alt="Pré-visualização"
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
            )}
          </TabsContent>

          <TabsContent value="url" className="space-y-4">
            <div>
              <Label htmlFor="imageUrl">URL da Imagem</Label>
              <div className="flex gap-2 mt-2">
                <Input
                  id="imageUrl"
                  type="url"
                  value={urlInput}
                  onChange={(e) => setUrlInput(e.target.value)}
                  placeholder="https://exemplo.com/imagem.jpg"
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      handleUrlSubmit()
                    }
                  }}
                />
                <Button onClick={handleUrlSubmit} type="button">
                  Adicionar
                </Button>
              </div>
            </div>
            {selectedImage && !selectedImage.startsWith("blob:") && (
              <div>
                <p className="text-sm font-medium mb-2">Pré-visualização:</p>
                <div className="relative w-full aspect-video rounded-lg overflow-hidden border">
                  <img
                    src={selectedImage || "/placeholder.svg"}
                    alt="Pré-visualização"
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  )
}
