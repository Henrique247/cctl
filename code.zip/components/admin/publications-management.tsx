"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { database } from "@/lib/firebase-config"
import { ref, onValue, push, update, remove } from "firebase/database"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Plus, Pencil, Trash2, Loader2, Share2 } from "lucide-react"
import Image from "next/image"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import ImageGallery from "./image-gallery"

interface Publication {
  id: string
  title: string
  content: string
  image?: string
  date: string
}

export default function PublicationsManagement() {
  const [publications, setPublications] = useState<Publication[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [editingPublication, setEditingPublication] = useState<Publication | null>(null)
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false)
  const [publicationToDelete, setPublicationToDelete] = useState<string | null>(null)
  const [submitting, setSubmitting] = useState(false)

  const [formData, setFormData] = useState({
    title: "",
    content: "",
    image: "",
    date: new Date().toISOString().split("T")[0],
  })

  useEffect(() => {
    const publicationsRef = ref(database, "publicacoes")
    const unsubscribe = onValue(publicationsRef, (snapshot) => {
      if (snapshot.exists()) {
        const data = snapshot.val()
        const publicationsList = Object.keys(data)
          .map((key) => ({
            id: key,
            ...data[key],
          }))
          .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
        setPublications(publicationsList)
      } else {
        setPublications([])
      }
      setLoading(false)
    })

    return () => unsubscribe()
  }, [])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setSubmitting(true)

    try {
      if (editingPublication) {
        // Update existing publication
        const publicationRef = ref(database, `publicacoes/${editingPublication.id}`)
        await update(publicationRef, formData)
      } else {
        // Create new publication
        const publicationsRef = ref(database, "publicacoes")
        await push(publicationsRef, formData)
      }

      setDialogOpen(false)
      resetForm()
    } catch (error) {
      console.error("Error saving publication:", error)
      alert("Erro ao salvar publicação. Tente novamente.")
    } finally {
      setSubmitting(false)
    }
  }

  const handleSharePublication = (publication: Publication) => {
    const shareText = `${publication.title}\n${window.location.origin}`
    const encodedText = encodeURIComponent(shareText)

    const shareOptions = {
      facebook: `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(window.location.origin)}&quote=${encodedText}`,
      whatsapp: `https://wa.me/?text=${encodedText}`,
      twitter: `https://twitter.com/intent/tweet?text=${encodedText}`,
      linkedin: `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(window.location.origin)}`,
    }

    // Create a simple menu or use web share API if available
    if (navigator.share) {
      navigator.share({
        title: publication.title,
        text: publication.content.substring(0, 100),
        url: window.location.origin,
      })
    } else {
      // Fallback: show social media links
      const shareWindow = window.open("", "share", "width=600,height=400")
      if (shareWindow) {
        shareWindow.document.write(`
          <h2>Compartilhar Publicação</h2>
          <a href="${shareOptions.facebook}" target="_blank">Facebook</a><br>
          <a href="${shareOptions.whatsapp}" target="_blank">WhatsApp</a><br>
          <a href="${shareOptions.twitter}" target="_blank">Twitter</a><br>
          <a href="${shareOptions.linkedin}" target="_blank">LinkedIn</a>
        `)
      }
    }
  }

  const handleEdit = (publication: Publication) => {
    setEditingPublication(publication)
    setFormData({
      title: publication.title,
      content: publication.content,
      image: publication.image || "",
      date: publication.date,
    })
    setDialogOpen(true)
  }

  const handleDelete = async () => {
    if (!publicationToDelete) return

    try {
      const publicationRef = ref(database, `publicacoes/${publicationToDelete}`)
      await remove(publicationRef)
      setDeleteDialogOpen(false)
      setPublicationToDelete(null)
    } catch (error) {
      console.error("Error deleting publication:", error)
      alert("Erro ao excluir publicação. Tente novamente.")
    }
  }

  const resetForm = () => {
    setFormData({
      title: "",
      content: "",
      image: "",
      date: new Date().toISOString().split("T")[0],
    })
    setEditingPublication(null)
  }

  const handleDialogClose = () => {
    setDialogOpen(false)
    resetForm()
  }

  const handleSelectImage = (url: string) => {
    setFormData({ ...formData, image: url })
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-8">
        <Loader2 className="w-8 h-8 animate-spin" />
      </div>
    )
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0">
        <CardTitle>Gerenciar Publicações</CardTitle>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => resetForm()}>
              <Plus className="mr-2 h-4 w-4" />
              Nova Publicação
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{editingPublication ? "Editar Publicação" : "Nova Publicação"}</DialogTitle>
              <DialogDescription>
                {editingPublication ? "Edite as informações da publicação" : "Adicione uma nova publicação ao sistema"}
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="title">Título</Label>
                <Input
                  id="title"
                  required
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                />
              </div>
              <div>
                <Label htmlFor="content">Conteúdo</Label>
                <Textarea
                  id="content"
                  required
                  value={formData.content}
                  onChange={(e) => setFormData({ ...formData, content: e.target.value })}
                  rows={8}
                />
              </div>
              <div>
                <Label>Imagem</Label>
                <div className="flex flex-col gap-2">
                  <ImageGallery onSelectImage={handleSelectImage} selectedImage={formData.image} />
                  {formData.image && (
                    <div className="relative w-full h-32 rounded-lg overflow-hidden border">
                      <Image
                        src={formData.image || "/placeholder.svg"}
                        alt="Pré-visualização"
                        fill
                        className="object-cover"
                      />
                    </div>
                  )}
                </div>
              </div>
              <div>
                <Label htmlFor="date">Data</Label>
                <Input
                  id="date"
                  type="date"
                  required
                  value={formData.date}
                  onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                />
              </div>
              <div className="flex gap-2 justify-end">
                <Button type="button" variant="outline" onClick={handleDialogClose}>
                  Cancelar
                </Button>
                <Button type="submit" disabled={submitting}>
                  {submitting ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Salvando...
                    </>
                  ) : (
                    "Salvar"
                  )}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </CardHeader>
      <CardContent>
        {publications.length > 0 ? (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Título</TableHead>
                <TableHead>Data</TableHead>
                <TableHead>Conteúdo</TableHead>
                <TableHead className="text-right">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {publications.map((publication) => (
                <TableRow key={publication.id}>
                  <TableCell className="font-medium">{publication.title}</TableCell>
                  <TableCell>{new Date(publication.date).toLocaleDateString("pt-BR")}</TableCell>
                  <TableCell className="max-w-md truncate">{publication.content}</TableCell>
                  <TableCell className="text-right">
                    <div className="flex gap-2 justify-end">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleSharePublication(publication)}
                        title="Compartilhar"
                      >
                        <Share2 className="h-4 w-4" />
                      </Button>
                      <Button variant="outline" size="sm" onClick={() => handleEdit(publication)}>
                        <Pencil className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          setPublicationToDelete(publication.id)
                          setDeleteDialogOpen(true)
                        }}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        ) : (
          <p className="text-center text-muted-foreground py-8">Nenhuma publicação cadastrada ainda.</p>
        )}
      </CardContent>

      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirmar exclusão</AlertDialogTitle>
            <AlertDialogDescription>
              Tem certeza que deseja excluir esta publicação? Esta ação não pode ser desfeita.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete}>Excluir</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </Card>
  )
}
