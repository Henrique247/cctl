"use client"

import { useEffect, useState } from "react"
import { database } from "@/lib/firebase-config"
import { ref, onValue, update, remove } from "firebase/database"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Loader2, Mail, Download, Trash2, Eye } from "lucide-react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"

interface Candidatura {
  id: string
  nomeCompleto: string
  email: string
  telefone: string
  cargo: string
  motivacao: string
  idade?: string
  habilidades?: string
  status: string
  dataSubmissao: string
}

export default function CandidaturasManagement() {
  const [candidaturas, setCandidaturas] = useState<Candidatura[]>([])
  const [loading, setLoading] = useState(true)
  const [viewDialogOpen, setViewDialogOpen] = useState(false)
  const [selectedCandidatura, setSelectedCandidatura] = useState<Candidatura | null>(null)
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false)
  const [candidaturaToDelete, setCandidaturaToDelete] = useState<string | null>(null)

  useEffect(() => {
    const candidaturasRef = ref(database, "candidaturas")
    const unsubscribe = onValue(candidaturasRef, (snapshot) => {
      if (snapshot.exists()) {
        const data = snapshot.val()
        const candidaturasList = Object.keys(data)
          .map((key) => ({
            id: key,
            ...data[key],
          }))
          .sort((a, b) => new Date(b.dataSubmissao).getTime() - new Date(a.dataSubmissao).getTime())
        setCandidaturas(candidaturasList)
      } else {
        setCandidaturas([])
      }
      setLoading(false)
    })

    return () => unsubscribe()
  }, [])

  const handleStatusChange = async (id: string, newStatus: string) => {
    try {
      const candidaturaRef = ref(database, `candidaturas/${id}`)
      await update(candidaturaRef, { status: newStatus })
    } catch (error) {
      console.error("Erro ao atualizar status:", error)
      alert("Erro ao atualizar status")
    }
  }

  const handleViewDetails = (candidatura: Candidatura) => {
    setSelectedCandidatura(candidatura)
    setViewDialogOpen(true)
  }

  const handleSendEmail = (email: string, nome: string) => {
    window.location.href = `mailto:${email}?subject=Candidatura CCTL - ${nome}`
  }

  const handleDelete = async () => {
    if (!candidaturaToDelete) return

    try {
      const candidaturaRef = ref(database, `candidaturas/${candidaturaToDelete}`)
      await remove(candidaturaRef)
      setDeleteDialogOpen(false)
      setCandidaturaToDelete(null)
    } catch (error) {
      console.error("Erro ao excluir candidatura:", error)
      alert("Erro ao excluir candidatura")
    }
  }

  const handleExportCSV = () => {
    const headers = ["Nome", "Email", "Telefone", "Cargo", "Status", "Data de Submissão", "Idade"]
    const rows = candidaturas.map((c) => [
      c.nomeCompleto,
      c.email,
      c.telefone,
      c.cargo,
      c.status,
      new Date(c.dataSubmissao).toLocaleDateString("pt-BR"),
      c.idade || "N/A",
    ])

    const csvContent = [headers, ...rows].map((row) => row.join(",")).join("\n")
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" })
    const link = document.createElement("a")
    link.href = URL.createObjectURL(blob)
    link.download = `candidaturas_${new Date().toISOString().split("T")[0]}.csv`
    link.click()
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <Loader2 className="w-6 h-6 animate-spin" />
      </div>
    )
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <CardTitle>Candidaturas (Cargos da CCTL)</CardTitle>
            <CardDescription>Gerencie as candidaturas para vagas da CCTL ({candidaturas.length} total)</CardDescription>
          </div>
          <Button onClick={handleExportCSV} variant="outline">
            <Download className="mr-2 h-4 w-4" />
            Exportar CSV
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {candidaturas.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">Nenhuma candidatura recebida ainda.</div>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Nome</TableHead>
                  <TableHead className="hidden md:table-cell">Email</TableHead>
                  <TableHead className="hidden lg:table-cell">Telefone</TableHead>
                  <TableHead>Cargo</TableHead>
                  <TableHead className="hidden xl:table-cell">Data</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {candidaturas.map((candidatura) => (
                  <TableRow key={candidatura.id}>
                    <TableCell className="font-medium">{candidatura.nomeCompleto}</TableCell>
                    <TableCell className="hidden md:table-cell">{candidatura.email}</TableCell>
                    <TableCell className="hidden lg:table-cell">{candidatura.telefone}</TableCell>
                    <TableCell>{candidatura.cargo}</TableCell>
                    <TableCell className="hidden xl:table-cell">
                      {new Date(candidatura.dataSubmissao).toLocaleDateString("pt-BR")}
                    </TableCell>
                    <TableCell>
                      <Select
                        value={candidatura.status}
                        onValueChange={(value) => handleStatusChange(candidatura.id, value)}
                      >
                        <SelectTrigger className="w-[140px]">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="em análise">Em Análise</SelectItem>
                          <SelectItem value="aceito">Aceito</SelectItem>
                          <SelectItem value="recusado">Recusado</SelectItem>
                          <SelectItem value="entrevista">Entrevista</SelectItem>
                        </SelectContent>
                      </Select>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleViewDetails(candidatura)}
                          title="Visualizar detalhes"
                        >
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleSendEmail(candidatura.email, candidatura.nomeCompleto)}
                          title="Enviar Email"
                        >
                          <Mail className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            setCandidaturaToDelete(candidatura.id)
                            setDeleteDialogOpen(true)
                          }}
                          title="Excluir"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>

      <Dialog open={viewDialogOpen} onOpenChange={setViewDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Detalhes da Candidatura</DialogTitle>
            <DialogDescription>Informações completas do candidato</DialogDescription>
          </DialogHeader>
          {selectedCandidatura && (
            <div className="space-y-4">
              <div>
                <h4 className="font-semibold mb-1">Nome Completo</h4>
                <p className="text-muted-foreground">{selectedCandidatura.nomeCompleto}</p>
              </div>
              <div>
                <h4 className="font-semibold mb-1">Email</h4>
                <p className="text-muted-foreground">{selectedCandidatura.email}</p>
              </div>
              <div>
                <h4 className="font-semibold mb-1">Telefone</h4>
                <p className="text-muted-foreground">{selectedCandidatura.telefone}</p>
              </div>
              <div>
                <h4 className="font-semibold mb-1">Cargo Desejado</h4>
                <p className="text-muted-foreground">{selectedCandidatura.cargo}</p>
              </div>
              {selectedCandidatura.idade && (
                <div>
                  <h4 className="font-semibold mb-1">Idade</h4>
                  <p className="text-muted-foreground">{selectedCandidatura.idade}</p>
                </div>
              )}
              <div>
                <h4 className="font-semibold mb-1">Motivação / Experiência / Competências</h4>
                <p className="text-muted-foreground whitespace-pre-wrap">{selectedCandidatura.motivacao}</p>
              </div>
              {selectedCandidatura.habilidades && (
                <div>
                  <h4 className="font-semibold mb-1">Habilidades</h4>
                  <p className="text-muted-foreground whitespace-pre-wrap">{selectedCandidatura.habilidades}</p>
                </div>
              )}
              <div>
                <h4 className="font-semibold mb-1">Data de Submissão</h4>
                <p className="text-muted-foreground">
                  {new Date(selectedCandidatura.dataSubmissao).toLocaleString("pt-BR")}
                </p>
              </div>
              <div>
                <h4 className="font-semibold mb-1">Status</h4>
                <p className="text-muted-foreground">{selectedCandidatura.status}</p>
              </div>
              <div className="flex gap-2 pt-4">
                <Button
                  className="flex-1"
                  onClick={() => handleSendEmail(selectedCandidatura.email, selectedCandidatura.nomeCompleto)}
                >
                  <Mail className="mr-2 h-4 w-4" />
                  Enviar Email
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirmar exclusão</AlertDialogTitle>
            <AlertDialogDescription>
              Tem certeza que deseja excluir esta candidatura? Esta ação não pode ser desfeita.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete}>Excluir</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </Card>
  )
}
